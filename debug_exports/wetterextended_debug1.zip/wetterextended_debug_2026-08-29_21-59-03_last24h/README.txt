WetterExtended Debug-Export der letzten 24 Stunden
Enthält Logs, Bilder, Forecasts, externe Responses und Auswertungsdaten, sofern vorhanden.
Textuelle Konfigurationen und Logs wurden auf Secrets geprüft und redacted.
